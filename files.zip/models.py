from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum

class RiskLevel(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"

class UserRole(str, Enum):
    ADMIN = "admin"
    CLINICIAN = "clinician"
    RESEARCHER = "researcher"

# ============ User Models ============
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: UserRole = UserRole.CLINICIAN

class UserDB(BaseModel):
    id: str = Field(alias="_id")
    email: str
    full_name: str
    role: UserRole
    created_at: datetime

class User(UserDB):
    pass

# ============ Patient Models ============
class PatientBasic(BaseModel):
    patient_id: str
    age: int
    gender: str
    lifestyle_factors: Optional[dict] = {}
    family_history: Optional[dict] = {}

class PatientVitals(BaseModel):
    blood_pressure: str  # e.g., "120/80"
    heart_rate: int
    bmi: float
    oxygen_saturation: float

class PatientLabResults(BaseModel):
    blood_sugar: Optional[float] = None
    hba1c: Optional[float] = None
    cholesterol: Optional[float] = None
    ldl: Optional[float] = None
    hdl: Optional[float] = None
    triglycerides: Optional[float] = None

class PatientCreate(PatientBasic):
    vitals: PatientVitals
    lab_results: PatientLabResults
    medical_notes: Optional[str] = None

class Patient(PatientCreate):
    id: str = Field(alias="_id")
    created_at: datetime
    updated_at: datetime

# ============ Risk Prediction Models ============
class DiseaseRiskScore(BaseModel):
    disease: str  # "heart_disease", "diabetes", "cancer"
    risk_score: float  # 0-100
    risk_level: RiskLevel
    confidence: float  # 0-1
    contributing_factors: List[str]

class RiskPredictionCreate(BaseModel):
    patient_id: str
    predictions: List[DiseaseRiskScore]
    overall_risk_score: float
    recommendations: List[str]
    timestamp: datetime

class RiskPrediction(RiskPredictionCreate):
    id: str = Field(alias="_id")
    created_by: str  # clinician ID