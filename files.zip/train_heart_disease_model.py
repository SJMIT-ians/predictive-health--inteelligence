import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import joblib

class HeartDiseaseModel:
    """TensorFlow model for predicting heart disease risk"""
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names = [
            'age', 'gender', 'blood_pressure_sys', 'blood_pressure_dia',
            'heart_rate', 'bmi', 'cholesterol', 'ldl', 'hdl', 'triglycerides'
        ]
    
    def build_model(self, input_dim: int):
        """Build neural network architecture"""
        self.model = keras.Sequential([
            layers.Dense(128, activation='relu', input_dim=input_dim),
            layers.BatchNormalization(),
            layers.Dropout(0.3),
            
            layers.Dense(64, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.3),
            
            layers.Dense(32, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.2),
            
            layers.Dense(16, activation='relu'),
            layers.Dense(1, activation='sigmoid')  # Binary classification
        ])
        
        self.model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy', keras.metrics.AUC()]
        )
    
    def train(self, X_train: np.ndarray, y_train: np.ndarray, 
              X_val: np.ndarray, y_val: np.ndarray, 
              epochs: int = 50, batch_size: int = 32):
        """Train the model"""
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=batch_size,
            early_stopping=keras.callbacks.EarlyStopping(
                monitor='val_loss', patience=10, restore_best_weights=True
            ),
            verbose=1
        )
        return history
    
    def predict(self, X: np.ndarray) -> tuple:
        """Make prediction and return risk score with confidence"""
        predictions = self.model.predict(X, verbose=0)
        risk_scores = (predictions * 100).flatten()
        confidence_scores = np.abs(predictions - 0.5).flatten() * 2
        return risk_scores, confidence_scores
    
    def save(self, model_path: str, scaler_path: str):
        """Save model and scaler"""
        self.model.save(model_path)
        joblib.dump(self.scaler, scaler_path)
    
    def load(self, model_path: str, scaler_path: str):
        """Load model and scaler"""
        self.model = keras.models.load_model(model_path)
        self.scaler = joblib.load(scaler_path)

# Example usage
if __name__ == "__main__":
    # Load sample data (replace with actual dataset)
    # data = pd.read_csv('heart_disease_data.csv')
    # X = data.drop('target', axis=1).values
    # y = data['target'].values
    
    # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    
    # model = HeartDiseaseModel()
    # model.build_model(X_train.shape[1])
    # history = model.train(X_train, y_train, X_test, y_test)
    # model.save('./models/heart_disease_model.h5', './models/scaler.pkl')
    
    print("Model architecture ready for training!")