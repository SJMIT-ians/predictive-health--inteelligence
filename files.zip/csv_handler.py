import csv
import io
from typing import List, Dict, Any
from fastapi import UploadFile, HTTPException

class CSVValidator:
    """Validates and processes CSV uploads"""
    
    REQUIRED_COLUMNS = {
        'patient_id', 'age', 'gender', 'blood_pressure', 
        'heart_rate', 'bmi', 'blood_sugar', 'cholesterol'
    }
    
    @staticmethod
    async def validate_and_parse(file: UploadFile) -> List[Dict[str, Any]]:
        """
        Validate CSV file and return parsed data
        """
        if file.content_type != "text/csv":
            raise HTTPException(status_code=400, detail="File must be CSV format")
        
        try:
            content = await file.read()
            stream = io.StringIO(content.decode('utf-8'))
            reader = csv.DictReader(stream)
            
            if reader.fieldnames is None:
                raise HTTPException(status_code=400, detail="CSV file is empty")
            
            # Validate required columns
            missing_columns = CSVValidator.REQUIRED_COLUMNS - set(reader.fieldnames)
            if missing_columns:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Missing columns: {', '.join(missing_columns)}"
                )
            
            records = []
            for row_num, row in enumerate(reader, start=2):
                try:
                    validated_row = CSVValidator._validate_row(row)
                    records.append(validated_row)
                except ValueError as e:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Invalid data at row {row_num}: {str(e)}"
                    )
            
            return records
        
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing CSV: {str(e)}")
    
    @staticmethod
    def _validate_row(row: Dict[str, str]) -> Dict[str, Any]:
        """Validate and convert individual row"""
        try:
            return {
                'patient_id': str(row['patient_id']).strip(),
                'age': int(row['age']),
                'gender': str(row['gender']).strip().lower(),
                'blood_pressure': str(row['blood_pressure']).strip(),
                'heart_rate': int(row['heart_rate']),
                'bmi': float(row['bmi']),
                'blood_sugar': float(row['blood_sugar']),
                'cholesterol': float(row['cholesterol']),
            }
        except (ValueError, KeyError) as e:
            raise ValueError(f"Invalid field value: {str(e)}")