'use client';

import React, { useEffect, useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import axios from 'axios';

interface RiskData {
  disease: string;
  risk_score: number;
  risk_level: 'low' | 'moderate' | 'high';
  confidence: number;
  contributing_factors: string[];
}

export default function RiskDashboard({ patientId }: { patientId: string }) {
  const [risks, setRisks] = useState<RiskData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRisks = async () => {
      try {
        const response = await axios.get(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/predictions/${patientId}`,
          {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          }
        );
        setRisks(response.data.predictions);
      } catch (err) {
        setError('Failed to load risk data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchRisks();
  }, [patientId]);

  if (loading) return <div className="text-center p-8">Loading...</div>;
  if (error) return <div className="text-red-600 p-8">{error}</div>;

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'moderate': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold mb-6">Risk Assessment Dashboard</h1>
      
      {/* Risk Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {risks.map((risk) => (
          <div key={risk.disease} className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-2 capitalize">{risk.disease.replace('_', ' ')}</h3>
            <div className={`inline-block px-3 py-1 rounded-full text-sm font-semibold mb-4 ${getRiskColor(risk.risk_level)}`}>
              {risk.risk_level.toUpperCase()}
            </div>
            <div className="text-3xl font-bold text-blue-600 mb-2">{risk.risk_score}%</div>
            <p className="text-sm text-gray-600 mb-4">Confidence: {(risk.confidence * 100).toFixed(1)}%</p>
            
            <div className="border-t pt-4">
              <p className="font-semibold text-sm mb-2">Contributing Factors:</p>
              <ul className="text-sm space-y-1">
                {risk.contributing_factors.slice(0, 3).map((factor, idx) => (
                  <li key={idx} className="text-gray-700">• {factor}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      {/* Risk Comparison Chart */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Risk Scores Comparison</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={risks}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="disease" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="risk_score" fill="#3b82f6" name="Risk Score (%)" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}