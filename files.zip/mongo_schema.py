# Patient Collection
patient_schema = {
    "patient_id": {"type": "string", "required": True},
    "age": {"type": "int", "required": True},
    "gender": {"type": "string", "enum": ["M", "F", "Other"]},
    "vital_signs": {
        "blood_pressure": {"type": "string"},
        "heart_rate": {"type": "int"},
        "bmi": {"type": "float"},
        "oxygen_saturation": {"type": "float"}
    },
    "lab_results": {
        "blood_sugar": {"type": "float"},
        "hba1c": {"type": "float"},
        "cholesterol": {"type": "float"}
    },
    "medical_history": {"type": "array"},
    "medications": {"type": "array"},
    "family_history": {"type": "object"},
    "created_at": {"type": "date"},
    "updated_at": {"type": "date"}
}

# Risk Predictions Collection
risk_prediction_schema = {
    "patient_id": {"type": "string", "required": True},
    "disease": {"type": "string", "enum": ["heart_disease", "diabetes", "cancer"]},
    "risk_score": {"type": "float", "min": 0, "max": 100},
    "risk_level": {"type": "string", "enum": ["low", "moderate", "high"]},
    "confidence": {"type": "float", "min": 0, "max": 1},
    "contributing_factors": {"type": "array"},
    "recommendations": {"type": "array"},
    "created_by": {"type": "string"},
    "created_at": {"type": "date"}
}

# Users Collection
user_schema = {
    "email": {"type": "string", "required": True, "unique": True},
    "password_hash": {"type": "string", "required": True},
    "full_name": {"type": "string"},
    "role": {"type": "string", "enum": ["admin", "clinician", "researcher"]},
    "created_at": {"type": "date"},
    "last_login": {"type": "date"}
}