# Predictive Health Intelligence Platform - Setup Guide

## 📋 Prerequisites

- **Docker & Docker Compose** (recommended for easy setup)
- Or manually:
  - Python 3.11+
  - Node.js 18+
  - MongoDB 7.0+

## 🚀 Quick Start (Docker)

```bash
# 1. Clone repository
git clone https://github.com/SJMIT'ians/predictive-health-intelligence.git
cd predictive-health-intelligence

# 2. Build and start all services
docker-compose up --build

# 3. Access the application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs
- MongoDB: localhost:27017